var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var PropsPrice = (function () {
    function PropsPrice() {
    }
    PropsPrice.prompt = 500;
    PropsPrice.reset = 500;
    PropsPrice.pause = 500;
    return PropsPrice;
}());
__reflect(PropsPrice.prototype, "PropsPrice");
//# sourceMappingURL=PropsPrice.js.map