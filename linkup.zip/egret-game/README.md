# egret连连看小游戏

## 特色
- [x]   关卡定制，每个关卡要清除的元素和背景图都不一样

## 主要功能
- [x]   解锁和选择关卡、元素
- [x]   游戏道具
- [x]   游戏商城
- [x]   游戏关卡
- [x]   存储

## 部分截图

<div>
    <img src="./show/1.png" alt="" width="24%" />　
    <img src="./show/2.png" alt="" width="24%" />　
    <img src="./show/3.png" alt="" width="24%" />　
    <img src="./show/4.png" alt="" width="24%" />　
    <img src="./show/5.png" alt="" width="24%" />　
    <img src="./show/6.png" alt="" width="24%" />　
    <img src="./show/7.png" alt="" width="24%" />　
    <img src="./show/8.png" alt="" width="24%" />　

</div>



## demo展示 http://www.maocanhua.cn/work/linkgame/

