class ColorGlowFilter {
	public static transparentGF= new egret.GlowFilter(0xFFFFFF, 0, 6, 6, 20, 1);//白色
    public static whiteGF= new egret.GlowFilter(0xFFFFFF, 1, 6, 6, 20, 1);//白色
    public static redGF = new egret.GlowFilter(0xDC143C, 1, 6, 6, 20, 1);  //红色
    public static blueGF = new egret.GlowFilter(0x00BFFF, 1, 6, 6, 20, 1);  //蓝色
    public static yellowGF = new egret.GlowFilter(0xdbe204, 1, 6, 6, 20, 1);  //黄色
}