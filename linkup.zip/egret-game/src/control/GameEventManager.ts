class GameEventManager{
	public static timeout(){
		egret.log('时间到')
	}
}