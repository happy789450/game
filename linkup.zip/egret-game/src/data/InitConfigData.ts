class InitConfigData {
	public static icon:number = 1000;
	public static chapter:number = 0;
	public static prompt:number = 3;
	public static pause:number = 3;
	public static reset:number = 3;
}