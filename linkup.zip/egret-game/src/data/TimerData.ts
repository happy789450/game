class TimerData {
	public static time = 90; //游戏时间单位秒
	public static pauseTime = 5;//单位秒
	public static eleDisappearTime = 200; //元素找到到消失的时间/毫秒
}