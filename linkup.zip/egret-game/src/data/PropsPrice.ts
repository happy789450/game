class PropsPrice {
	public static prompt: number = 500;
	public static reset: number = 500;
	public static pause: number = 500;
}