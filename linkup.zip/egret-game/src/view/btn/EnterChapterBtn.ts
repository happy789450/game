class EnterChapterBtn extends BaseBtn{
	protected do() {
		SceenControl.loadChapter();
	}
}