class EnterStoreBtn extends BaseBtn{
	protected do() {
		SceenControl.loadStore();
	}
}